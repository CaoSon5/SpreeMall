import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../config/theme/app_text_styles.dart';
import '../models/product.dart';
import '../screens/home/product_grid_section.dart'; // Dùng lại ProductCard cho đồng bộ giao diện

/// Section "✨ Có thể bạn sẽ thích" - dùng chung cho nhiều màn hình (Trang cá
/// nhân, Đơn hàng...). Đọc THẬT từ Firestore collection 'products', xáo trộn
/// ngẫu nhiên mỗi lần build rồi lấy ra [limit] sản phẩm để hiển thị.
///
/// 🆕 KHÔNG code cứng danh sách sản phẩm - Admin đăng sản phẩm mới lên app
/// sẽ tự động có cơ hội xuất hiện ở đây, không cần sửa code gì thêm.
class RecommendedProductsSection extends StatelessWidget {
  final int limit;
  final EdgeInsetsGeometry padding;

  const RecommendedProductsSection({
    super.key,
    this.limit = 6,
    this.padding = const EdgeInsets.symmetric(horizontal: 15),
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('products').snapshots(),
      builder: (context, snapshot) {
        final docs = snapshot.data?.docs ?? [];
        if (docs.isEmpty) return const SizedBox.shrink();

        // 🆕 Xáo trộn ngẫu nhiên mỗi lần build - Random() không cố định seed
        // nên mỗi lần mở lại trang sẽ thấy 1 tổ hợp sản phẩm khác nhau.
        final shuffled = List.of(docs)..shuffle(Random());
        final products = shuffled.take(limit).map((d) => Product.fromMap(d.id, d.data())).toList();

        return Padding(
          padding: padding,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('✨ Có thể bạn sẽ thích', style: AppTextStyles.heading3.copyWith(fontSize: 16)),
              const SizedBox(height: 12),
              GridView.builder(
                itemCount: products.length,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 0.7,
                ),
                itemBuilder: (context, index) => ProductCard(product: products[index]),
              ),
            ],
          ),
        );
      },
    );
  }
}
