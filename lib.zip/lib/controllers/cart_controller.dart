import 'dart:convert';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart'; // 🆕 Lưu giỏ hàng bằng Hive (local storage) theo yêu cầu môn học
import 'package:firebase_auth/firebase_auth.dart'; // 🆕 Chỉ dùng để biết uid hiện tại (không lưu cart lên Firestore nữa)
import '../models/product.dart';

/// Tên Hive box dùng để lưu giỏ hàng - mở 1 lần duy nhất trong main.dart
/// bằng Hive.openBox<String>(cartHiveBoxName) TRƯỚC khi runApp().
const String cartHiveBoxName = 'cart_box';

/// Một dòng sản phẩm trong giỏ hàng.
/// 🆕 Thêm field `size` - vì 1 sản phẩm chọn 2 size khác nhau (VD: giày size
/// 39 và size 41) phải được coi là 2 dòng RIÊNG BIỆT trong giỏ, không được
/// gộp làm 1 như trước (đây là lỗi bạn báo - đã sửa bằng cách đưa `size`
/// vào khoá định danh mỗi dòng, xem `_sameLine()` bên dưới).
class CartItem {
  final Product product;
  int quantity;
  bool selected;
  final String? size; // null nếu sản phẩm không phân loại theo size

  CartItem({
    required this.product,
    required this.quantity,
    this.selected = true,
    this.size,
  });

  int get totalPrice => product.price * quantity;

  Map<String, dynamic> toJson() => {
        'productId': product.id,
        'quantity': quantity,
        'selected': selected,
        'size': size,
        'product': product.toMap(), // Lưu nguyên snapshot sản phẩm để Hive không cần tra cứu lại Firestore
      };

  static CartItem fromJson(Map<String, dynamic> json) {
    final productId = json['productId'] as String;
    final productMap = Map<String, dynamic>.from(json['product'] as Map);
    return CartItem(
      product: Product.fromMap(productId, productMap),
      quantity: (json['quantity'] ?? 1) as int,
      selected: (json['selected'] ?? true) as bool,
      size: json['size'] as String?,
    );
  }
}

/// Quản lý giỏ hàng toàn app sử dụng GetxController.
/// 🆕 Giỏ hàng được lưu bằng HIVE (bộ nhớ cục bộ trên máy/thiết bị),
/// theo đúng yêu cầu môn học - không còn lưu lên Firestore nữa.
/// Mỗi tài khoản (uid) có 1 key riêng trong Hive box, nên: tắt app mở lại
/// vẫn còn giỏ hàng, và đăng nhập tài khoản khác trên CÙNG máy sẽ thấy
/// đúng giỏ hàng của tài khoản đó (không bị lẫn giỏ hàng của nhau).
class CartController extends GetxController {
  static CartController get instance => Get.find<CartController>();

  final List<CartItem> _items = [];

  bool _isLoading = false;

  Box<String> get _box => Hive.box<String>(cartHiveBoxName);

  String _keyFor(String uid) => 'cart_$uid';

  List<CartItem> get items => List.unmodifiable(_items);

  bool get isEmpty => _items.isEmpty;

  int get totalQuantity => _items.fold(0, (sum, item) => sum + item.quantity);

  int get selectedCount => _items.where((i) => i.selected).length;

  bool get isAllSelected => _items.isNotEmpty && _items.every((i) => i.selected);

  int get selectedTotalPrice => _items.where((i) => i.selected).fold(0, (sum, i) => sum + i.totalPrice);

  /// So khớp đúng 1 dòng trong giỏ: cùng sản phẩm VÀ cùng size.
  /// Đây là điểm mấu chốt để sửa lỗi "khác size mà bị gộp làm 1".
  bool _sameLine(CartItem item, String productId, String? size) {
    return item.product.id == productId && item.size == size;
  }

  bool contains(String productId, {String? size}) => _items.any((i) => _sameLine(i, productId, size));

  void addProduct(Product product, {int quantity = 1, String? size}) {
    final index = _items.indexWhere((i) => _sameLine(i, product.id, size));
    if (index >= 0) {
      _items[index].quantity += quantity;
    } else {
      _items.add(CartItem(product: product, quantity: quantity, size: size));
    }
    update();
    _saveCart();
  }

  /// 🆕 Xử lý tính năng "Mua ngay" NGAY TRONG GIỎ (dùng khi bạn muốn Mua ngay
  /// vẫn đi qua giỏ hàng). Lưu ý: từ bản này, màn Chi tiết sản phẩm KHÔNG
  /// gọi hàm này nữa - "Mua ngay" giờ đi thẳng vào Checkout mà KHÔNG đụng
  /// tới giỏ hàng, xem CheckoutController.startQuickBuy(). Hàm này được
  /// giữ lại để không phá vỡ những chỗ khác lỡ còn gọi tới.
  void buyNow(Product product, {int quantity = 1, String? size}) {
    for (final item in _items) {
      item.selected = false;
    }
    final index = _items.indexWhere((i) => _sameLine(i, product.id, size));
    if (index >= 0) {
      _items[index].quantity += quantity;
      _items[index].selected = true;
    } else {
      _items.add(CartItem(product: product, quantity: quantity, selected: true, size: size));
    }
    update();
    _saveCart();
  }

  void removeItem(String productId, {String? size}) {
    _items.removeWhere((i) => _sameLine(i, productId, size));
    update();
    _saveCart();
  }

  void increaseQuantity(String productId, {String? size}) {
    final index = _items.indexWhere((i) => _sameLine(i, productId, size));
    if (index >= 0) {
      _items[index].quantity++;
      update();
      _saveCart();
    }
  }

  void decreaseQuantity(String productId, {String? size}) {
    final index = _items.indexWhere((i) => _sameLine(i, productId, size));
    if (index >= 0) {
      if (_items[index].quantity <= 1) {
        _items.removeAt(index);
      } else {
        _items[index].quantity--;
      }
      update();
      _saveCart();
    }
  }

  void toggleSelected(String productId, {String? size}) {
    final index = _items.indexWhere((i) => _sameLine(i, productId, size));
    if (index >= 0) {
      _items[index].selected = !_items[index].selected;
      update();
      _saveCart();
    }
  }

  void toggleSelectAll(bool value) {
    for (final item in _items) {
      item.selected = value;
    }
    update();
    _saveCart();
  }

  /// Xoá các sản phẩm đã chọn khỏi giỏ (dùng sau khi "đặt hàng" thành công).
  void checkoutSelected() {
    _items.removeWhere((i) => i.selected);
    update();
    _saveCart();
  }

  void clear() {
    _items.clear();
    update();
    _saveCart();
  }

  /// Chỉ xoá giỏ hàng khỏi bộ nhớ (RAM) khi Đăng xuất, KHÔNG đụng tới dữ
  /// liệu đã lưu trong Hive, để lần sau tài khoản đó đăng nhập lại trên
  /// đúng máy này vẫn thấy đúng giỏ hàng.
  void clearLocalOnly() {
    _items.clear();
    update();
  }

  // ====================================================================
  // 🆕 LƯU / TẢI GIỎ HÀNG BẰNG HIVE (local storage theo từng tài khoản)
  // ====================================================================

  void _saveCart() {
    if (_isLoading) return;
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    try {
      final jsonList = _items.map((i) => i.toJson()).toList();
      _box.put(_keyFor(uid), jsonEncode(jsonList));
    } catch (e) {
      // ignore: avoid_print
      print('Lỗi khi lưu giỏ hàng vào Hive: $e');
    }
  }

  /// Tải giỏ hàng đã lưu của 1 tài khoản từ Hive (gọi ngay sau khi đăng
  /// nhập thành công hoặc lúc mở app mà đã có session cũ).
  Future<void> loadCart(String uid) async {
    _isLoading = true;
    try {
      _items.clear();

      final raw = _box.get(_keyFor(uid));
      if (raw == null || raw.isEmpty) {
        update();
        return;
      }

      final decoded = jsonDecode(raw) as List<dynamic>;
      for (final entry in decoded) {
        try {
          _items.add(CartItem.fromJson(Map<String, dynamic>.from(entry as Map)));
        } catch (_) {
          // Bỏ qua dòng dữ liệu lỗi (VD: sản phẩm cũ format khác), không crash cả giỏ hàng
        }
      }

      update();
    } catch (e) {
      // ignore: avoid_print
      print('Lỗi khi tải giỏ hàng từ Hive: $e');
    } finally {
      _isLoading = false;
    }
  }
}
