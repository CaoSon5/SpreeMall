import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import '../models/user_role.dart';

/// Quản lý vai trò (role) của tài khoản đang đăng nhập trong toàn bộ app.
/// Được nạp 1 lần duy nhất bằng Get.put(RoleController()) trong main.dart,
/// sau đó truy cập ở bất cứ đâu bằng RoleController.instance.
///
/// 🆕 Từ bản này: role được LẮNG NGHE REAL-TIME từ Firestore (không chỉ đọc
/// 1 lần như trước). Nếu bạn tự tay đổi field 'role' của tài khoản đang
/// đăng nhập ngay trên Firebase Console, badge role + nút "Vào khu quản trị"
/// trong app sẽ tự cập nhật ngay lập tức, KHÔNG cần đăng xuất/đăng nhập lại.
class RoleController extends GetxController {
  static RoleController get instance => Get.find<RoleController>();

  /// Vai trò hiện tại, mặc định là 'user' cho tới khi xác thực xong.
  final Rx<UserRole> role = UserRole.user.obs;

  /// true khi đang tải role từ Firestore (VD: lúc splash / lúc login)
  final RxBool isLoadingRole = false.obs;

  /// uid của tài khoản đang gắn với role hiện tại (để tránh load nhầm role
  /// của tài khoản cũ khi đổi user)
  String? _currentUid;

  /// 🆕 Theo dõi thay đổi Firestore real-time cho đúng 1 tài khoản tại 1 thời điểm
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _roleSubscription;

  bool get isAdmin => role.value.isAdmin;
  bool get isUser => !isAdmin;

  /// Lấy role của 1 tài khoản (theo uid) từ Firestore collection 'users',
  /// cập nhật state ngay lập tức, ĐỒNG THỜI bắt đầu lắng nghe real-time
  /// mọi thay đổi tiếp theo của field 'role' trên chính document đó.
  /// Gọi hàm này ngay sau khi đăng nhập/đăng ký thành công, hoặc khi app
  /// khởi động mà đã có session cũ (FirebaseAuth currentUser != null).
  Future<UserRole> fetchRole(String uid) async {
    isLoadingRole.value = true;
    try {
      // Nếu đang lắng nghe 1 tài khoản khác trước đó -> huỷ đi trước
      await _roleSubscription?.cancel();

      final docRef = FirebaseFirestore.instance.collection('users').doc(uid);

      final doc = await docRef.get();
      final resolvedRole = userRoleFromString(doc.data()?['role'] as String?);

      role.value = resolvedRole;
      _currentUid = uid;

      // 🆕 Bắt đầu lắng nghe real-time - mỗi khi field 'role' đổi trên
      // Firestore (kể cả tự tay sửa trên Console), role.value sẽ tự cập
      // nhật ngay, mọi nơi dùng Obx/GetX sẽ tự vẽ lại giao diện.
      _roleSubscription = docRef.snapshots().listen((snapshot) {
        final liveRole = userRoleFromString(snapshot.data()?['role'] as String?);
        if (liveRole != role.value) {
          role.value = liveRole;
        }
      });

      return resolvedRole;
    } catch (e) {
      // Nếu lỗi mạng/Firestore, an toàn nhất là coi như 'user' thường
      role.value = UserRole.user;
      return UserRole.user;
    } finally {
      isLoadingRole.value = false;
    }
  }

  /// Gán role trực tiếp (VD: dùng ngay sau khi Admin vừa đổi role cho ai đó
  /// và cần cập nhật UI ngay mà không cần gọi lại Firestore).
  void setRole(UserRole newRole) {
    role.value = newRole;
  }

  /// Reset role về mặc định khi Đăng xuất - đồng thời huỷ luôn lắng nghe
  /// real-time để không bị dính role của tài khoản vừa đăng xuất.
  void reset() {
    _roleSubscription?.cancel();
    _roleSubscription = null;
    role.value = UserRole.user;
    _currentUid = null;
  }

  String? get currentUid => _currentUid;

  @override
  void onClose() {
    _roleSubscription?.cancel();
    super.onClose();
  }
}
