import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'cart_controller.dart';
import '../models/product.dart';
import '../models/address.dart';
import '../models/payment_method.dart';
import '../models/order_status.dart';

/// Controller cho luồng Thanh toán, hỗ trợ 2 chế độ:
///
/// 1) Thanh toán từ Giỏ hàng: `quickBuyItem == null` -> lấy các sản phẩm
///    đang được tick `selected` trong CartController.
/// 2) "Mua ngay" từ trang chi tiết sản phẩm: `quickBuyItem != null` -> chỉ
///    thanh toán ĐÚNG 1 sản phẩm này, KHÔNG đụng vào giỏ hàng (không thêm,
///    không xoá, không đổi trạng thái chọn của bất kỳ dòng nào trong giỏ).
class CheckoutController extends GetxController {
  static CheckoutController get instance => Get.find<CheckoutController>();

  /// Địa chỉ giao hàng đang được chọn (lấy từ sổ địa chỉ AddressController)
  final Rx<Address?> selectedAddress = Rx<Address?>(null);

  /// Phương thức thanh toán đang chọn
  final Rx<PaymentMethod> selectedPaymentMethod = PaymentMethod.cod.obs;

  final RxBool isPlacingOrder = false.obs;

  /// 🆕 Sản phẩm "Mua ngay" tạm thời - chỉ sống trong phiên Checkout hiện
  /// tại, không lưu Hive, không đụng giỏ hàng thật.
  final Rx<CartItem?> quickBuyItem = Rx<CartItem?>(null);

  /// 🆕 Gọi từ trang Chi tiết sản phẩm khi bấm "Mua ngay"
  void startQuickBuy(Product product, {required int quantity, String? size}) {
    quickBuyItem.value = CartItem(product: product, quantity: quantity, selected: true, size: size);
  }

  void clearQuickBuy() {
    quickBuyItem.value = null;
  }

  /// Danh sách sản phẩm sẽ hiển thị & đặt hàng ở Checkout:
  /// ưu tiên quickBuyItem (Mua ngay) - nếu không có thì lấy sản phẩm đang
  /// được chọn trong giỏ hàng (đặt hàng bình thường từ giỏ).
  List<CartItem> get checkoutItems {
    final quick = quickBuyItem.value;
    if (quick != null) return [quick];
    return CartController.instance.items.where((i) => i.selected).toList();
  }

  double get checkoutTotal => checkoutItems.fold<int>(0, (sum, i) => sum + i.totalPrice).toDouble();

  void selectAddress(Address address) {
    selectedAddress.value = address;
  }

  void changePaymentMethod(PaymentMethod method) {
    selectedPaymentMethod.value = method;
  }

  /// Đặt lại lựa chọn phương thức thanh toán mỗi lần vào lại màn Checkout
  void resetPaymentMethod() {
    selectedPaymentMethod.value = PaymentMethod.cod;
  }

  Future<bool> processOrder() async {
    final address = selectedAddress.value;

    if (address == null) {
      Get.snackbar('Thiếu thông tin', 'Vui lòng chọn địa chỉ giao hàng', snackPosition: SnackPosition.BOTTOM);
      return false;
    }

    final itemsToOrder = checkoutItems;

    if (itemsToOrder.isEmpty) {
      Get.snackbar('Thiếu thông tin', 'Không có sản phẩm nào để đặt hàng', snackPosition: SnackPosition.BOTTOM);
      return false;
    }

    final totalAmount = checkoutTotal;
    final isQuickBuy = quickBuyItem.value != null;

    isPlacingOrder.value = true;
    try {
      await FirebaseFirestore.instance.collection('orders').add({
        'uid': FirebaseAuth.instance.currentUser?.uid ?? '',
        'customerName': address.name,
        'customerPhone': address.phone,
        'customerAddress': address.detail,
        'paymentMethod': selectedPaymentMethod.value.value,
        'totalAmount': totalAmount,
        'status': OrderStatus.pending.value,
        'items': itemsToOrder
            .map((i) => {
                  'productId': i.product.id,
                  'productName': i.product.name,
                  'quantity': i.quantity,
                  'price': i.product.price,
                  'size': i.size, // Lưu lại size đã chọn vào đơn hàng
                  'storeId': i.product.storeId, // 🆕 Để Seller lọc được đơn hàng chứa sản phẩm của mình
                })
            .toList(),
        'createdAt': FieldValue.serverTimestamp(),
      });

      // 🆕 Trừ tồn kho + cộng "Đã bán" NGAY khi đặt hàng thành công (không
      // đợi tới lúc Admin xác nhận), giống hành vi giữ chỗ hàng của Shopee.
      // Dùng batch + FieldValue.increment để cộng/trừ AN TOÀN dù nhiều
      // người đặt cùng lúc (không bị ghi đè lẫn nhau).
      final productsRef = FirebaseFirestore.instance.collection('products');
      final batch = FirebaseFirestore.instance.batch();
      for (final item in itemsToOrder) {
        batch.update(productsRef.doc(item.product.id), {
          'stock': FieldValue.increment(-item.quantity),
          'soldCount': FieldValue.increment(item.quantity),
        });
      }
      await batch.commit();

      if (isQuickBuy) {
        // Mua ngay: không đụng gì tới giỏ hàng thật -> chỉ xoá state tạm
        quickBuyItem.value = null;
      } else {
        // Đặt hàng từ giỏ: xoá các sản phẩm vừa đặt khỏi giỏ, giữ lại phần chưa chọn
        CartController.instance.checkoutSelected();
      }

      return true;
    } catch (e) {
      Get.snackbar('Lỗi', 'Không thể đặt hàng lúc này, vui lòng thử lại: $e', snackPosition: SnackPosition.BOTTOM);
      return false;
    } finally {
      isPlacingOrder.value = false;
    }
  }
}
