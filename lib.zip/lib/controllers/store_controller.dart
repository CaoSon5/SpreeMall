import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import '../models/store.dart';

/// Quản lý luồng "Đăng ký bán hàng": user tự gửi yêu cầu mở cửa hàng,
/// Admin duyệt/từ chối. Mỗi tài khoản (uid) chỉ được sở hữu ĐÚNG 1 cửa hàng
/// tại một thời điểm (ràng buộc kiểm tra ở [requestStore]).
class StoreController extends GetxController {
  static StoreController get instance => Get.find<StoreController>();

  CollectionReference<Map<String, dynamic>> get _storesRef => FirebaseFirestore.instance.collection('stores');

  /// Lắng nghe real-time cửa hàng của CHÍNH tài khoản đang đăng nhập (nếu có).
  /// Trả về null nếu tài khoản này chưa từng gửi yêu cầu mở cửa hàng nào.
  Stream<Store?> watchMyStore() {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return Stream.value(null);

    return _storesRef.where('ownerUid', isEqualTo: uid).snapshots().map((snap) {
      if (snap.docs.isEmpty) return null;
      final doc = snap.docs.first;
      return Store.fromMap(doc.id, doc.data());
    });
  }

  /// Gửi yêu cầu mở cửa hàng mới. Chặn nếu tài khoản đã có 1 cửa hàng rồi
  /// (dù đang pending/approved) - ĐÚNG như quy tắc "1 tài khoản = 1 cửa hàng"
  /// bạn đã chọn. Nếu cửa hàng cũ bị "rejected", cho phép gửi lại (ghi đè).
  Future<String?> requestStore({
    required String name,
    required String description,
    required String logoUrl,
    String bannerUrl = '', // 🆕
    required List<String> categoryIds,
  }) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return 'Vui lòng đăng nhập trước.';

    final existingSnap = await _storesRef.where('ownerUid', isEqualTo: user.uid).get();

    if (existingSnap.docs.isNotEmpty) {
      final existing = Store.fromMap(existingSnap.docs.first.id, existingSnap.docs.first.data());
      if (existing.status != StoreStatus.rejected) {
        return 'Tài khoản của bạn đã có 1 cửa hàng (${existing.status.label}). Mỗi tài khoản chỉ được mở 1 cửa hàng.';
      }
      // Bị từ chối trước đó -> cho gửi lại bằng cách cập nhật y hệt document cũ
      await _storesRef.doc(existingSnap.docs.first.id).update({
        'name': name,
        'description': description,
        'logoUrl': logoUrl,
        'bannerUrl': bannerUrl, // 🆕
        'categoryIds': categoryIds,
        'status': StoreStatus.pending.value,
        'rejectReason': null,
      });
      return null; // Thành công
    }

    await _storesRef.add({
      'name': name,
      'description': description,
      'logoUrl': logoUrl,
      'bannerUrl': bannerUrl, // 🆕
      'ownerUid': user.uid,
      'ownerEmail': user.email ?? '',
      'categoryIds': categoryIds,
      'status': StoreStatus.pending.value,
      'rejectReason': null,
      'createdAt': FieldValue.serverTimestamp(),
    });
    return null; // Thành công
  }

  /// 🆕 Admin tạo cửa hàng TRỰC TIẾP (bỏ qua bước "chờ duyệt") và gán ngay
  /// cho 1 tài khoản có sẵn - tìm tài khoản theo email. Dùng khi Admin muốn
  /// tự thiết lập sẵn các thương hiệu lớn (VD: Samsung, Apple...) làm cửa
  /// hàng chính thức, thay vì đợi người dùng tự đăng ký.
  ///
  /// Trả về null nếu thành công, hoặc thông báo lỗi nếu:
  /// - Không tìm thấy tài khoản với email đó
  /// - Tài khoản đó đã sở hữu 1 cửa hàng khác rồi (ràng buộc 1 tài khoản = 1 cửa hàng)
  Future<String?> createStoreForUser({
    required String ownerEmail,
    required String name,
    required String description,
    required String logoUrl,
    String bannerUrl = '', // 🆕
    required List<String> categoryIds,
  }) async {
    final usersRef = FirebaseFirestore.instance.collection('users');
    final userSnap = await usersRef.where('email', isEqualTo: ownerEmail.trim()).limit(1).get();

    if (userSnap.docs.isEmpty) {
      return 'Không tìm thấy tài khoản nào với email "$ownerEmail". Tài khoản đó phải đăng ký trước.';
    }

    final ownerDoc = userSnap.docs.first;
    final ownerUid = ownerDoc.id;

    final existingStore = await _storesRef.where('ownerUid', isEqualTo: ownerUid).get();
    if (existingStore.docs.isNotEmpty) {
      final existing = Store.fromMap(existingStore.docs.first.id, existingStore.docs.first.data());
      return 'Tài khoản này đã sở hữu cửa hàng "${existing.name}" (${existing.status.label}) rồi. Mỗi tài khoản chỉ được 1 cửa hàng.';
    }

    final storeDoc = await _storesRef.add({
      'name': name,
      'description': description,
      'logoUrl': logoUrl,
      'bannerUrl': bannerUrl, // 🆕
      'ownerUid': ownerUid,
      'ownerEmail': ownerEmail.trim(),
      'categoryIds': categoryIds,
      'status': StoreStatus.approved.value, // 🆕 Duyệt luôn, không cần chờ
      'rejectReason': null,
      'createdAt': FieldValue.serverTimestamp(),
    });

    await usersRef.doc(ownerUid).update({'storeId': storeDoc.id});

    // Tự động tạo/cập nhật brand tương ứng - giống hệt logic approveStore()
    final brandsRef = FirebaseFirestore.instance.collection('brands');
    final existingBrand = await brandsRef.where('name', isEqualTo: name).limit(1).get();
    if (existingBrand.docs.isEmpty) {
      await brandsRef.add({'name': name, 'url': logoUrl, 'categoryIds': categoryIds});
    } else {
      await existingBrand.docs.first.reference.update({'url': logoUrl, 'categoryIds': categoryIds});
    }

    return null; // Thành công
  }

  /// 🆕 Admin duyệt cửa hàng: đổi status -> approved, đồng thời gắn storeId
  /// vào đúng document user (users/{ownerUid}.storeId) để toàn app biết tài
  /// khoản này giờ là chủ 1 cửa hàng. Đồng thời tự động tạo/cập nhật brand
  /// tương ứng trong collection 'brands' để cửa hàng hiện luôn ở mục
  /// "Thương hiệu ưa chuộng" - không cần làm thủ công thêm.
  Future<void> approveStore(Store store) async {
    final batch = FirebaseFirestore.instance.batch();

    batch.update(_storesRef.doc(store.id), {'status': StoreStatus.approved.value, 'rejectReason': null});
    batch.update(FirebaseFirestore.instance.collection('users').doc(store.ownerUid), {'storeId': store.id});

    await batch.commit();

    // Tạo/cập nhật brand tương ứng (ngoài batch vì cần đọc trước để tránh trùng)
    final brandsRef = FirebaseFirestore.instance.collection('brands');
    final existingBrand = await brandsRef.where('name', isEqualTo: store.name).limit(1).get();

    if (existingBrand.docs.isEmpty) {
      await brandsRef.add({
        'name': store.name,
        'url': store.logoUrl,
        'categoryIds': store.categoryIds,
      });
    } else {
      await existingBrand.docs.first.reference.update({
        'url': store.logoUrl,
        'categoryIds': store.categoryIds,
      });
    }
  }

  /// 🆕 Seller tự sửa thông tin cửa hàng của MÌNH (mô tả, logo, banner,
  /// ngành hàng). KHÔNG cho đổi `name` vì tên này đang gắn chặt với field
  /// `brand` của mọi sản phẩm đã đăng dưới cửa hàng đó - đổi tên sẽ làm các
  /// sản phẩm cũ bị "lạc" khỏi cửa hàng (không còn khớp brand nữa).
  Future<void> updateStoreInfo({
    required String storeId,
    required String description,
    required String logoUrl,
    required String bannerUrl,
    required List<String> categoryIds,
  }) async {
    await _storesRef.doc(storeId).update({
      'description': description,
      'logoUrl': logoUrl,
      'bannerUrl': bannerUrl,
      'categoryIds': categoryIds,
    });

    // Đồng bộ lại logo/categoryIds cho đúng brand tương ứng (để "Thương hiệu
    // ưa chuộng" ở Trang chủ cũng cập nhật logo mới ngay).
    final storeSnap = await _storesRef.doc(storeId).get();
    final storeName = storeSnap.data()?['name'] as String?;
    if (storeName != null) {
      final brandsRef = FirebaseFirestore.instance.collection('brands');
      final brandSnap = await brandsRef.where('name', isEqualTo: storeName).limit(1).get();
      if (brandSnap.docs.isNotEmpty) {
        await brandSnap.docs.first.reference.update({'url': logoUrl, 'categoryIds': categoryIds});
      }
    }
  }

  Future<void> rejectStore(Store store, {String? reason}) async {
    await _storesRef.doc(store.id).update({
      'status': StoreStatus.rejected.value,
      'rejectReason': reason ?? 'Không đáp ứng yêu cầu của sàn.',
    });

    // Nếu trước đó đã từng được duyệt (rất hiếm, VD Admin thu hồi) -> gỡ storeId khỏi user
    await FirebaseFirestore.instance.collection('users').doc(store.ownerUid).update({'storeId': FieldValue.delete()});
  }

  Stream<List<Store>> watchAllStores() {
    return _storesRef.snapshots().map((snap) => snap.docs.map((d) => Store.fromMap(d.id, d.data())).toList());
  }
}
