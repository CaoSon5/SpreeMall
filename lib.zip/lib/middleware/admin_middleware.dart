import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/role_controller.dart';
import '../routes/app_routes.dart';

/// Middleware gắn vào các GetPage của khu vực Admin.
/// Nếu tài khoản hiện tại không có role admin, tự động chuyển hướng
/// về Home để chặn truy cập trái phép vào khu vực quản trị
/// (kể cả khi người dùng gõ thẳng route bằng tay).
class AdminMiddleware extends GetMiddleware {
  @override
  int? get priority => 1;

  @override
  RouteSettings? redirect(String? route) {
    final isAdmin = RoleController.instance.isAdmin;

    if (!isAdmin) {
      return const RouteSettings(name: AppRoutes.home);
    }
    return null; // Cho phép đi tiếp vào route admin
  }
}
