/// Định nghĩa các vai trò (role) trong hệ thống SpreeMall.
/// Hiện tại có 2 role: người dùng thường (user) và quản trị viên (admin).
enum UserRole {
  user,
  admin,
}

/// Các hàm tiện ích để chuyển đổi qua lại giữa UserRole <-> String
/// (String là kiểu dữ liệu được lưu trong Firestore, field 'role' của
/// collection 'users').
extension UserRoleX on UserRole {
  /// Giá trị lưu xuống Firestore, VD: role == UserRole.admin -> 'admin'
  String get value {
    switch (this) {
      case UserRole.admin:
        return 'admin';
      case UserRole.user:
        return 'user';
    }
  }

  /// Tên hiển thị lên giao diện (tiếng Việt)
  String get label {
    switch (this) {
      case UserRole.admin:
        return 'Quản trị viên';
      case UserRole.user:
        return 'Khách hàng';
    }
  }

  bool get isAdmin => this == UserRole.admin;
}

/// Parse chuỗi lấy từ Firestore về đúng enum UserRole.
/// Nếu dữ liệu bị thiếu hoặc sai định dạng -> mặc định trả về UserRole.user
/// (an toàn hơn là mặc định admin).
UserRole userRoleFromString(String? raw) {
  switch (raw) {
    case 'admin':
      return UserRole.admin;
    case 'user':
      return UserRole.user;
    default:
      return UserRole.user;
  }
}
