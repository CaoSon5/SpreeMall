import 'package:flutter/material.dart';
import '../config/theme/app_colors.dart';

/// Trạng thái đơn hàng dùng chung cho CẢ màn hình khách hàng (order_history)
/// và màn hình Admin (admin_order_management). Đảm bảo 2 nơi luôn khớp nhau
/// 100% (không lệch label/màu sắc).
///
/// Luồng thực tế: pending -> confirmed -> shipping -> delivered
/// Có thể huỷ (cancelled) khi đang ở pending hoặc confirmed.
enum OrderStatus {
  pending,
  confirmed,
  shipping,
  delivered,
  cancelled,
}

extension OrderStatusX on OrderStatus {
  /// Giá trị lưu xuống Firestore field 'status'
  String get value => name;

  String get label {
    switch (this) {
      case OrderStatus.pending:
        return 'Chờ xác nhận';
      case OrderStatus.confirmed:
        return 'Đã xác nhận';
      case OrderStatus.shipping:
        return 'Đang giao';
      case OrderStatus.delivered:
        return 'Đã giao';
      case OrderStatus.cancelled:
        return 'Đã huỷ';
    }
  }

  Color get color {
    switch (this) {
      case OrderStatus.pending:
        return AppColors.warning;
      case OrderStatus.confirmed:
        return const Color(0xFF2196F3);
      case OrderStatus.shipping:
        return AppColors.primary;
      case OrderStatus.delivered:
        return AppColors.success;
      case OrderStatus.cancelled:
        return AppColors.error;
    }
  }

  IconData get icon {
    switch (this) {
      case OrderStatus.pending:
        return Icons.hourglass_empty_rounded;
      case OrderStatus.confirmed:
        return Icons.fact_check_outlined;
      case OrderStatus.shipping:
        return Icons.local_shipping_outlined;
      case OrderStatus.delivered:
        return Icons.check_circle_outline;
      case OrderStatus.cancelled:
        return Icons.cancel_outlined;
    }
  }

  /// Khách hàng chỉ được phép huỷ đơn khi còn ở trạng thái chờ xác nhận.
  bool get canBeCancelledByCustomer => this == OrderStatus.pending;
}

OrderStatus orderStatusFromString(String? raw) {
  return OrderStatus.values.firstWhere(
    (e) => e.name == raw,
    orElse: () => OrderStatus.pending,
  );
}
