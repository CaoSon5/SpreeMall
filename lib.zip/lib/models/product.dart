import 'package:flutter/material.dart';
class Product {
  final String id;
  final String name;
  final String category;
  final int price;
  final int? oldPrice;
  final double rating;
  final int soldCount;
  final int stock;


  final String image;
  final IconData icon;
  final Color iconBgColor;
  final String description;
  final bool isFlashSale; // 🆕 Đánh dấu sản phẩm hiển thị ở mục Flash Sale
  final List<String> sizes; // 🆕 Danh sách size do Admin tự định nghĩa (VD: ['S','M','L'] hoặc ['39','40','41'])
  final String brand; // 🆕 Tên thương hiệu CHÍNH XÁC (VD: 'Nike', 'Adidas') - dùng để lọc khi bấm vào logo thương hiệu
  final String gender; // 🆕 'nam' | 'nu' | 'unisex' (mặc định 'unisex' -> hiện ở cả 2 mục Nam và Nữ)
  final List<String> images; // 🆕 Ảnh PHỤ (ngoài `image` là ảnh chính/ảnh đại diện) - hiện dạng carousel ở trang chi tiết
  final Map<String, String> specs; // 🆕 Thông số kỹ thuật TUỲ Ý do Admin tự đặt (VD: "RAM": "12GB", "Chất liệu": "Da lộn"...) - phù hợp mọi loại sản phẩm
  final String storeId; // 🆕 ID cửa hàng (nếu sản phẩm này thuộc 1 Seller cụ thể) - rỗng nghĩa là sản phẩm "chính hãng" do Admin đăng, không thuộc cửa hàng nào


  const Product({
    required this.id,
    required this.name,
    required this.category,
    required this.price,
    this.oldPrice,
    this.rating = 4.5,
    this.soldCount = 0,
    this.stock = 100,


    this.image = '',

  
    this.icon = Icons.image_outlined,
    this.iconBgColor = const Color(0xFFF3F3F3),

    this.description = '',
    this.isFlashSale = false, // 🆕
    this.sizes = const [], // 🆕
    this.brand = '', // 🆕
    this.gender = 'unisex', // 🆕
    this.images = const [], // 🆕
    this.specs = const {}, // 🆕
    this.storeId = '', // 🆕
  });

  int get discountPercent {
    if (oldPrice == null || oldPrice! <= price) return 0;
    return (((oldPrice! - price) / oldPrice!) * 100).round();
  }

  bool get hasDiscount => discountPercent > 0;


  bool get hasImage => image.isNotEmpty;

  // ====================================================================
  // 🆕 Hỗ trợ đọc/ghi Firestore - phục vụ CRUD sản phẩm từ khu vực Admin.
  // Không đụng tới `icon`/`iconBgColor` (kiểu IconData/Color khó lưu gọn
  // xuống Firestore) vì các màn hình khách hàng chủ yếu hiển thị theo
  // `image` (link ảnh) nên không ảnh hưởng.
  // ====================================================================

  /// Tạo Product từ 1 document Firestore (collection 'products').
  factory Product.fromMap(String id, Map<String, dynamic> data) {
    return Product(
      id: id,
      name: (data['name'] ?? '') as String,
      category: (data['category'] ?? '') as String,
      price: _toInt(data['price']),
      oldPrice: data['oldPrice'] == null ? null : _toInt(data['oldPrice']),
      rating: (data['rating'] == null) ? 4.5 : (data['rating'] as num).toDouble(),
      soldCount: _toInt(data['soldCount']),
      stock: data['stock'] == null ? 100 : _toInt(data['stock']),
      image: (data['image'] ?? '') as String,
      description: (data['description'] ?? '') as String,
      isFlashSale: (data['isFlashSale'] ?? false) as bool, // 🆕
      sizes: (data['sizes'] as List<dynamic>? ?? []).map((e) => e.toString()).toList(), // 🆕
      brand: (data['brand'] ?? '') as String, // 🆕
      gender: (data['gender'] ?? 'unisex') as String, // 🆕
      images: (data['images'] as List<dynamic>? ?? []).map((e) => e.toString()).toList(), // 🆕
      specs: Map<String, String>.from(data['specs'] as Map? ?? {}), // 🆕
      storeId: (data['storeId'] ?? '') as String, // 🆕
    );
  }

  /// 🆕 Toàn bộ ảnh để hiện carousel ở trang chi tiết: ảnh chính (`image`)
  /// luôn đứng đầu, theo sau là các ảnh phụ (`images`). Loại bỏ trùng/rỗng.
  List<String> get allImages {
    final list = <String>[
      if (image.isNotEmpty) image,
      ...images.where((e) => e.isNotEmpty && e != image),
    ];
    return list;
  }

  /// Chuyển Product thành Map để ghi xuống Firestore.
  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'category': category,
      'price': price,
      'oldPrice': oldPrice,
      'rating': rating,
      'soldCount': soldCount,
      'stock': stock,
      'image': image,
      'description': description,
      'isFlashSale': isFlashSale, // 🆕
      'sizes': sizes, // 🆕
      'brand': brand, // 🆕
      'gender': gender, // 🆕
      'images': images, // 🆕
      'specs': specs, // 🆕
      'storeId': storeId, // 🆕
    };
  }

  static int _toInt(dynamic value) {
    if (value == null) return 0;
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse(value.toString()) ?? 0;
  }
}