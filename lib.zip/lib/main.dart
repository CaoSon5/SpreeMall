import 'dart:convert'; // Bắt buộc phải có để dùng json.decode
import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // Bắt buộc phải có để dùng rootBundle quét thư mục assets
import 'package:firebase_core/firebase_core.dart'; 
import 'package:cloud_firestore/cloud_firestore.dart'; // Thêm thư viện kết nối Firestore
import 'package:get/get.dart'; // 🆕 THÊM IMPORT GETX
import 'package:hive_flutter/hive_flutter.dart'; // 🆕 Lưu giỏ hàng cục bộ bằng Hive
import 'package:firebase_auth/firebase_auth.dart'; // 🆕 Lắng nghe trạng thái đăng nhập xuyên suốt app
import 'package:spreemall/controllers/checkout_controller.dart';
import 'package:spreemall/controllers/cart_controller.dart'; // 🆕 IMPORT THÊM CART CONTROLLER
import 'package:spreemall/controllers/role_controller.dart'; // 🆕 IMPORT ROLE CONTROLLER (phân quyền user/admin)
import 'package:spreemall/controllers/address_controller.dart'; // 🆕 IMPORT ADDRESS CONTROLLER (sổ địa chỉ)
import 'package:spreemall/controllers/store_controller.dart'; // 🆕 Quản lý yêu cầu mở cửa hàng (đa gian hàng)
import 'package:spreemall/controllers/profile_controller.dart'; // 🆕 Đồng bộ lại thông tin cá nhân khi F5
import 'package:spreemall/data/mock_products.dart'; // 🆕 Dùng để seed dữ liệu sản phẩm mẫu lên Firestore lần đầu
import 'firebase_options.dart';         

import 'config/theme/app_theme.dart';
import 'routes/app_routes.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized(); 

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // 🆕 KHỞI TẠO HIVE (lưu giỏ hàng cục bộ theo yêu cầu môn học)
  // Phải mở Box TRƯỚC khi bất kỳ ai gọi CartController.loadCart()/_saveCart().
  await Hive.initFlutter();
  await Hive.openBox<String>(cartHiveBoxName);

  // KÍCH HOẠT: Tự động quét và đồng bộ ảnh từ assets lên Firebase khi mở app
  await autoUploadDataToFirebase();

  // 🆕 Seed 3 sản phẩm demo lên Firestore collection 'products' (chỉ chạy 1 lần
  // nếu collection đang trống) để khu vực Admin và trang chủ dùng chung 1
  // nguồn dữ liệu thật duy nhất, thay vì Home đọc mock còn Admin đọc Firestore.
  await autoSeedProductsToFirebase();
  
  // ====================================================================
  // NẠP CONTROLLER VÀO HỆ THỐNG GETX
  // ====================================================================
  Get.put(CheckoutController());
  Get.put(CartController()); // 🆕 THÊM DÒNG NÀY ĐỂ HẾT LỖI ĐỎ KHI BẤM ĐẶT HÀNG
  Get.put(RoleController()); // 🆕 Nạp RoleController để quản lý phân quyền user/admin xuyên suốt app
  Get.put(AddressController()); // 🆕 Nạp AddressController để quản lý sổ địa chỉ giao hàng
  Get.put(StoreController()); // 🆕 Nạp StoreController để quản lý yêu cầu mở cửa hàng

  // ====================================================================
  // 🆕 LẮNG NGHE TRẠNG THÁI ĐĂNG NHẬP XUYÊN SUỐT APP (authStateChanges)
  // ----------------------------------------------------------------------
  // Vấn đề cần giải quyết: trên Flutter Web, khi người dùng bấm F5, trình
  // duyệt tải lại ĐÚNG route đang đứng (VD: #/home) và BỎ QUA hẳn
  // splash_screen.dart - nơi trước đây mình đặt logic "kiểm tra đăng nhập
  // -> lấy role -> lấy giỏ hàng". Kết quả: sau khi F5, role bị về mặc định
  // 'user' và tên/email hiển thị trống dù Firebase vẫn đang đăng nhập.
  //
  // Cách sửa: gắn thẳng vào FirebaseAuth.instance.authStateChanges() ngay
  // tại đây - callback này LUÔN chạy mỗi khi có người dùng đăng nhập
  // (dù vào từ splash, F5 giữa chừng, hay bất kỳ route nào), nên không còn
  // phụ thuộc splash_screen nữa.
  // ====================================================================
  FirebaseAuth.instance.authStateChanges().listen((user) async {
    if (user == null) {
      // Không có ai đăng nhập -> đảm bảo mọi state đều sạch
      RoleController.instance.reset();
      CartController.instance.clearLocalOnly();
      UserProfileController.instance.clearProfile();
      return;
    }

    // Có tài khoản đang đăng nhập -> đồng bộ lại TOÀN BỘ dữ liệu cá nhân
    try {
      final userDoc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
      final data = userDoc.data();

      // 1. Role (real-time listener đã có sẵn bên trong fetchRole)
      await RoleController.instance.fetchRole(user.uid);

      // 2. Giỏ hàng đã lưu của tài khoản này
      await CartController.instance.loadCart(user.uid);

      // 3. Thông tin cá nhân (tên, sđt, giới tính, ngày sinh...) để Profile
      // không còn hiện "Người dùng SpreeMall / chưa cập nhật email" nữa.
      if (data != null) {
        UserProfileController.instance.update(
          name: (data['name'] ?? '') as String,
          email: (data['email'] ?? user.email ?? '') as String,
          phone: (data['phone'] ?? '') as String,
          gender: (data['gender'] ?? '') as String,
          birthday: (data['birthday'] ?? '') as String,
        );
      }
    } catch (e) {
      // ignore: avoid_print
      print('Lỗi khi đồng bộ dữ liệu tài khoản sau authStateChanges: $e');
    }
  });

  runApp(const ShopMateApp());
}

// ====================================================================
// 🆕 SEED / ĐỒNG BỘ LẠI SẢN PHẨM MẪU LÊN FIRESTORE
// ====================================================================
// 🆕 SEED SẢN PHẨM MẪU LÊN FIRESTORE - CHỈ CHẠY ĐÚNG 1 LẦN DUY NHẤT
// ----------------------------------------------------------------------
// Bản trước dùng set(merge:true) chạy MỖI LẦN mở app -> hậu quả: Admin xoá
// hoặc sửa 1 trong 3 sản phẩm demo, mở lại app là bị "hồi sinh"/ghi đè về
// y như cũ, không xoá/sửa được thật sự (đúng lỗi bạn báo).
//
// Sửa lại: dùng 1 document đánh dấu `_meta/seed_products` với field
// `seeded: true`. Nếu đã seed rồi (document tồn tại) -> BỎ QUA HẲN, không
// đụng gì tới 3 sản phẩm demo nữa -> Admin sửa/xoá thoải mái, vĩnh viễn.
// Chỉ lần ĐẦU TIÊN app chạy (document chưa tồn tại) mới seed 1 lần.
// ====================================================================
Future<void> autoSeedProductsToFirebase() async {
  try {
    final seedFlagRef = FirebaseFirestore.instance.collection('_meta').doc('seed_products');
    final seedFlagDoc = await seedFlagRef.get();

    if (seedFlagDoc.exists) {
      print("✅ [Auto-Seed Products] Đã seed từ trước rồi, bỏ qua (Admin có toàn quyền sửa/xoá 3 sản phẩm demo).");
      return;
    }

    print("🔄 [Auto-Seed Products] Lần đầu mở app - seed ${MockProducts.all.length} sản phẩm demo...");

    final productsRef = FirebaseFirestore.instance.collection('products');
    for (int i = 0; i < MockProducts.all.length; i++) {
      final product = MockProducts.all[i];
      final data = product.toMap();
      data['isFlashSale'] = i < 2; // 2 sản phẩm đầu hiển thị ở mục Flash Sale
      await productsRef.doc(product.id).set(data);
    }

    // Đánh dấu đã seed xong - từ lần mở app tiếp theo sẽ không đụng gì nữa
    await seedFlagRef.set({'seeded': true, 'seededAt': FieldValue.serverTimestamp()});

    print("🎉 [Auto-Seed Products] Seed lần đầu hoàn tất! Các lần mở app sau sẽ không seed lại nữa.");
  } catch (e) {
    print("❌ [Auto-Seed Products] Gặp lỗi: $e");
  }
}

// ====================================================================
// HÀM TỰ ĐỘNG QUÉT THƯ MỤC VÀ ĐỒNG BỘ LÊN FIREBASE 100% TỰ ĐỘNG
// ====================================================================
Future<void> autoUploadDataToFirebase() async {
  print("🔄 [Firebase Auto-Sync] Đang kích hoạt phương thức đồng bộ an toàn...");

  try {
    List<String> allBanners = [
      'assets/images/banners/banner1.png',
      'assets/images/banners/banner2.png',
      'assets/images/banners/banner3.png',
      'assets/images/banners/banner4.png',
    ];

    print("📊 Danh sách chuẩn bị đồng bộ: ${allBanners.length} banners.");

    final CollectionReference bannersRef = FirebaseFirestore.instance.collection('banners');
    
    final existingBannersSnapshot = await bannersRef.get();
    final List<String> firebaseBannerUrls = existingBannersSnapshot.docs
        .map((doc) => doc['url'] as String)
        .toList();

    for (String path in allBanners) {
      if (!firebaseBannerUrls.contains(path)) {
        await bannersRef.add({
          'url': path,
          'createdAt': FieldValue.serverTimestamp(),
        });
        print("🆕 [Auto-Banner] Đã đồng bộ thành công lên Firebase: $path");
      } else {
        print("✅ [Auto-Banner] Đường dẫn đã tồn tại trên Firebase, bỏ qua: $path");
      }
    }
    
    print("🎉 [Firebase Auto-Sync] Tất cả dữ liệu Banner đã được đồng bộ hoàn tất!");
  } catch (e) {
    print("❌ [Firebase Auto-Sync] Gặp lỗi: $e");
  }
}

class ShopMateApp extends StatelessWidget {
  const ShopMateApp({super.key});

  @override
  Widget build(BuildContext context) {
    // 🆕 ĐỔI THÀNH GetMaterialApp và thay cấu hình route
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SpreeMall',
      theme: AppTheme.lightTheme,

      initialRoute: AppRoutes.splash,
      getPages: AppRoutes.routes, 
    );
  }
}