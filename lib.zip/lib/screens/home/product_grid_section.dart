import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart'; // 🆕 Đọc sản phẩm thật từ Firestore

import '../../config/theme/app_colors.dart';
import '../../config/theme/app_text_styles.dart';
import '../../controllers/cart_controller.dart';
import '../../models/product.dart';
import '../../utils/formatters.dart';
import '../../widgets/custom_section_title.dart';
import '../product/product_detail_screen.dart';

class ProductGridSection extends StatelessWidget {
  const ProductGridSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const CustomSectionTitle(title: "Sản phẩm nổi bật"),
          // 🆕 StreamBuilder đọc trực tiếp collection 'products' trên Firestore
          // -> sản phẩm Admin vừa đăng sẽ hiện lên đây ngay lập tức (real-time).
          StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: FirebaseFirestore.instance.collection('products').snapshots(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Padding(
                  padding: EdgeInsets.symmetric(vertical: 24),
                  child: Center(child: CircularProgressIndicator()),
                );
              }

              final docs = snapshot.data?.docs ?? [];
              final products = docs.map((d) => Product.fromMap(d.id, d.data())).toList();

              if (products.isEmpty) {
                return const Padding(
                  padding: EdgeInsets.symmetric(vertical: 24),
                  child: Center(child: Text('Chưa có sản phẩm nào')),
                );
              }

              return GridView.builder(
                itemCount: products.length,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 0.7,
                ),
                itemBuilder: (context, index) {
                  return ProductCard(product: products[index]);
                },
              );
            },
          ),
        ],
      ),
    );
  }
}

/// Card sản phẩm dùng chung (Trang chủ, có thể tái sử dụng ở Yêu thích).
class ProductCard extends StatelessWidget {
  final Product product;

  const ProductCard({super.key, required this.product});

  void _openDetail(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ProductDetailScreen(product: product),
      ),
    );
  }

  void _addToCart(BuildContext context) {
    CartController.instance.addProduct(product);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        duration: const Duration(milliseconds: 1200),
        content: Text('Đã thêm "${product.name}" vào giỏ hàng'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _openDetail(context),
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
          // 🆕 Đổ bóng nhẹ cho card trông nổi khối, đỡ phẳng lì như trước
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(
                children: [
                  Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: product.iconBgColor,
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(16),
                      ),
                    ),
                    child: Center(
                      child: product.image.isNotEmpty
                          ? Padding(
                              padding: const EdgeInsets.all(12),
                              child: product.image.startsWith('http')
                                  ? Image.network(
                                      product.image,
                                      fit: BoxFit.contain,
                                      errorBuilder: (_, __, ___) => Icon(product.icon, size: 46, color: AppColors.primary),
                                    )
                                  : Image.asset(
                                      product.image,
                                      fit: BoxFit.contain,
                                      errorBuilder: (_, __, ___) => Icon(product.icon, size: 46, color: AppColors.primary),
                                    ),
                            )
                          : Icon(
                              product.icon,
                              size: 46,
                              color: AppColors.primary,
                            ),
                    ),
                  ),
                  if (product.hasDiscount)
                    Positioned(
                      top: 8,
                      left: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 7,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(colors: [Color(0xFFFF6B4A), AppColors.primary]),
                          borderRadius: BorderRadius.circular(6),
                          boxShadow: [
                            BoxShadow(color: AppColors.primary.withOpacity(0.35), blurRadius: 4, offset: const Offset(0, 2)),
                          ],
                        ),
                        child: Text(
                          '-${product.discountPercent}%',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 10, 10, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    product.name,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: AppTextStyles.heading3.copyWith(fontSize: 13.5, height: 1.25),
                  ),
                  const SizedBox(height: 4),
                  // 🆕 Hàng rating + đã bán - giúp card trông đáng tin cậy hơn,
                  // giống các sàn TMĐT thật (Shopee/Tiki đều có dòng này).
                  Row(
                    children: [
                      const Icon(Icons.star_rounded, size: 14, color: Colors.amber),
                      const SizedBox(width: 2),
                      Text(
                        product.rating.toStringAsFixed(1),
                        style: AppTextStyles.caption.copyWith(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(width: 6),
                      Container(width: 3, height: 3, decoration: const BoxDecoration(color: AppColors.textHint, shape: BoxShape.circle)),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          'Đã bán ${product.soldCount}',
                          style: AppTextStyles.caption,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              formatVnd(product.price),
                              style: AppTextStyles.price.copyWith(fontSize: 15),
                            ),
                            // 🆕 Giá gốc gạch ngang - chỉ hiện khi có giảm giá
                            if (product.hasDiscount)
                              Text(
                                formatVnd(product.oldPrice ?? product.price),
                                style: AppTextStyles.caption.copyWith(
                                  decoration: TextDecoration.lineThrough,
                                  color: AppColors.textHint,
                                ),
                              ),
                          ],
                        ),
                      ),
                      // 🆕 Nút thêm giỏ hàng dạng nút tròn có nền, nổi bật và
                      // dễ bấm hơn icon trơn như trước.
                      InkWell(
                        borderRadius: BorderRadius.circular(20),
                        onTap: () => _addToCart(context),
                        child: Container(
                          padding: const EdgeInsets.all(6),
                          decoration: const BoxDecoration(
                            color: AppColors.primary,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.add_shopping_cart_rounded,
                            color: Colors.white,
                            size: 16,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
